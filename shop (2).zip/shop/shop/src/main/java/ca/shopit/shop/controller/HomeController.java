package ca.shopit.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.ui.Model;

import ca.shopit.shop.model.Cart;
import ca.shopit.shop.model.Products;
import ca.shopit.shop.repo.ProductsRepository;




@Controller
public class HomeController {

    @Autowired
    private ProductsRepository prepo;

    @Autowired
    private Cart cart;
    

    @GetMapping("/")
    public String home() {
        return "index";
    }
    
    @GetMapping("/products")
    public String products(Model model) {
        model.addAttribute("products", prepo.findAllProducts());
        return "products";
    }

    @GetMapping("/products/{id}")
    public String productDetails(@PathVariable("id") Long id, Model model) {
        Products product = prepo.findById(id).orElse(null);  // Fetches the product by ID
        if (product != null) {
            model.addAttribute("product", product);
            model.addAttribute("products", prepo.findAllProducts());  // Adds the product to the model
            return "productDetails";  // Renders the 'productDetails.html' page
        } else {
            return "error";  // Renders an error page if the product is not found
        }
    }

    @PostMapping("/cart/add")
public String addToCart(@RequestParam("id") int id,
                        @RequestParam("name") String name,
                        @RequestParam("price") Long price,
                        @RequestParam("description") String description,
                        @RequestParam("stock") int quantity,
                        RedirectAttributes redirectAttributes, Model model) {
    Products product = new Products();
    product.setId(id); // Set this if you're updating an existing item
    product.setName(name);
    product.setPrice(price);
    product.setDescription(description);
    product.setStock(quantity); // Use 'quantity' for cart quantity
 
    prepo.addToCart(product);
    System.out.println(product.toString());
 
    // Set alert message
    redirectAttributes.addFlashAttribute("alertMessage", "Product added to cart successfully!");
    model.addAttribute("products", prepo.findAllProducts());
 
    // Redirect to the product details page
    return "redirect:/products"; // Adjust the path as necessary
}

    
    @GetMapping("/cart")
    public String viewCart(Model model) {
        List<Products> cartList = prepo.getCartList();
        for (Products products : cartList) {
            System.out.println(products.getName());
        }
        model.addAttribute("cartList", cartList);
        return "cart"; // Thymeleaf template for cart
    }
    
}
