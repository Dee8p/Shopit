package ca.shopit.shop.repo;

import ca.shopit.shop.model.Products;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class ProductsRepository {

    private final JdbcTemplate jdbcTemplate;

    public ProductsRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // RowMapper to map ResultSet to Product entity
    private static final class ProductsRowMapper implements RowMapper<Products> {
        @Override
        public Products mapRow(ResultSet rs, int rowNum) throws SQLException {
            Products product = new Products();
            product.setId(rs.getInt("id"));
            product.setName(rs.getString("name"));
            product.setPrice(rs.getLong("price"));
            product.setStock(rs.getInt("stock"));
            product.setDescription(rs.getString("description"));
            return product;
        }
    }

    // Save or update a product
    public Products save(Products product) {
        if (product.getId() == -1) {
            // Insert new product
            jdbcTemplate.update("INSERT INTO product (name, price, stock, description) VALUES (?, ?, ?, ?)",
                    product.getName(), product.getPrice(), product.getStock(), product.getDescription());
        } else {
            // Update existing product
            jdbcTemplate.update("UPDATE product SET name = ?, price = ?, stock = ?, description = ? WHERE id = ?",
                    product.getName(), product.getPrice(), product.getStock(), product.getDescription(), product.getId());
        }
        return product;
    }

    public Products addToCart(Products product) {

        
        if (product.getId() != -1) {
            // Insert new product into cart
            jdbcTemplate.update("INSERT INTO cart (name, price, quantity, description) VALUES (?, ?, ?, ?)",
                    product.getName(), product.getPrice(), product.getStock(), product.getDescription());
        } else {
            // Update existing product in cart
            jdbcTemplate.update("UPDATE cart SET name = ?, price = ?, quantity = ?, description = ? WHERE id = ?",
                    product.getName(), product.getPrice(), product.getStock(), product.getDescription(), product.getId());
        }
        System.out.println("addToCart is getting called!");
        return product;
    }
    

    // Find by id
    public Optional<Products> findById(Long id) {
        String sql = "SELECT * FROM product WHERE id = ?";
        return jdbcTemplate.query(sql, new ProductsRowMapper(), id).stream().findFirst();
    }

    // Find all products
    public List<Products> findAllProducts() {
        String sql = "SELECT * FROM product";
        return jdbcTemplate.query(sql, new ProductsRowMapper());
    }

    public List<Products> getCartList() {
    String sql = "SELECT id, name, price, quantity AS stock, description FROM cart";

    System.out.println("getCartList is getting called! or not?");
    return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Products.class));
}


    // Delete product by id
    public void deleteById(Long id) {
        String sql = "DELETE FROM product WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }

    public void deleteByIdCart(Long id) {
        String sql = "DELETE FROM cart WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }
}
