package ca.shopit.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeeppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeeppApplication.class, args);
		System.out.println("Working fine");
	}

}
