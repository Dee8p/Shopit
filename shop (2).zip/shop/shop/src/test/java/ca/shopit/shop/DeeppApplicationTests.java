package ca.shopit.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeeppApplicationTests {

	@Test
	void contextLoads() {
	}

}
